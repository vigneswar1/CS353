let current = "0";
let previous = "";
let operator = null;

const result = document.getElementById("result");
const history = document.getElementById("history");

function updateDisplay() {
    result.textContent = current;
    history.textContent = previous + (operator ? " " + operator : "");
}

function appendNumber(num) {
    if (current === "0") {
        current = num;
    } else {
        current += num;
    }
    updateDisplay();
}

function appendDecimal() {
    if (!current.includes(".")) {
        current += ".";
        updateDisplay();
    }
}

function clearAll() {
    current = "0";
    previous = "";
    operator = null;
    updateDisplay();
}

function toggleSign() {
    current = (parseFloat(current) * -1).toString();
    updateDisplay();
}

function percent() {
    current = (parseFloat(current) / 100).toString();
    updateDisplay();
}

function setOperator(op) {
    if (operator !== null) {
        calculate();
    }
    previous = current;
    operator = op;
    current = "0";
    updateDisplay();
}

function calculate() {
    if (operator === null) return;

    const prev = parseFloat(previous);
    const curr = parseFloat(current);
    let computation;

    switch (operator) {
        case '+':
            computation = prev + curr;
            break;
        case '-':
            computation = prev - curr;
            break;
        case '*':
            computation = prev * curr;
            break;
        case '/':
            computation = prev / curr;
            break;
    }

    current = computation.toString();
    operator = null;
    previous = "";
    updateDisplay();
}
