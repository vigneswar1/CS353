from django.shortcuts import render, redirect
from .models import Student

def form(request):
    if request.method == "POST":
        name = request.POST["name"]
        roll = request.POST["roll"]

        s1 = int(request.POST["s1"])
        s2 = int(request.POST["s2"])
        s3 = int(request.POST["s3"])
        s4 = int(request.POST["s4"])
        s5 = int(request.POST["s5"])
        s6 = int(request.POST["s6"])

        total = s1+s2+s3+s4+s5+s6
        percentage = total/6

        if percentage < 35:
            grade = "F"
        elif percentage < 50:
            grade = "D"
        elif percentage < 60:
            grade = "C"
        elif percentage < 75:
            grade = "B"
        elif percentage < 90:
            grade = "A"
        else:
            grade = "A+"

        Student.objects.create(
            name=name, roll=roll,
            s1=s1, s2=s2, s3=s3, s4=s4, s5=s5, s6=s6,
            total=total, percentage=percentage, grade=grade
        )

        return redirect("/list/")

    return render(request, "form.html")


def list(request):
    students = Student.objects.all()
    return render(request, "list.html", {"students": students})
