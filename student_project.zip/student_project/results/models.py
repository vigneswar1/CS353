from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    roll = models.CharField(max_length=20)
    s1 = models.IntegerField()
    s2 = models.IntegerField()
    s3 = models.IntegerField()
    s4 = models.IntegerField()
    s5 = models.IntegerField()
    s6 = models.IntegerField()
    total = models.IntegerField()
    percentage = models.FloatField()
    grade = models.CharField(max_length=2)

    def __str__(self):
        return self.name
